package io.klimiter.architecture

import com.lemonappdev.konsist.api.Konsist
import java.nio.file.Files
import java.nio.file.Path
import kotlin.io.path.absolutePathString
import kotlin.io.path.exists
import kotlin.io.path.isDirectory
import kotlin.io.path.name
import kotlin.io.path.readText
import kotlin.test.assertTrue

internal object ArchitectureTestSupport {
    private val root: Path by lazy { findProjectRoot() }

    fun projectRoot(): Path = root

    fun modulePath(moduleName: String): Path = root.resolve(moduleName)

    fun mainKotlinPath(moduleName: String): Path = modulePath(moduleName).resolve("src/main/kotlin")

    fun scopeFromMain(moduleName: String) = Konsist.scopeFromDirectory(mainKotlinPath(moduleName).absolutePathString())

    fun kotlinFiles(moduleName: String): List<Path> {
        val main = mainKotlinPath(moduleName)
        if (!main.exists()) return emptyList()

        return Files.walk(main)
            .use { stream ->
                stream
                    .filter { Files.isRegularFile(it) }
                    .filter { it.toString().endsWith(".kt") }
                    .sorted()
                    .toList()
            }
    }

    fun textFiles(moduleName: String): List<SourceFile> = kotlinFiles(moduleName).map { file ->
        SourceFile(
            path = root.relativize(file).toString().replace('\\', '/'),
            text = file.readText(),
        )
    }

    fun assertModuleExists(moduleName: String) {
        assertTrue(modulePath(moduleName).isDirectory(), "Expected module '$moduleName' to exist")
    }

    private fun findProjectRoot(): Path {
        val start = Path.of("").toAbsolutePath().normalize()

        return generateSequence(start) { it.parent }
            .firstOrNull { candidate ->
                candidate.resolve("settings.gradle.kts").exists() &&
                    candidate.resolve("klimiter-core").isDirectory() &&
                    candidate.resolve("klimiter-redis").isDirectory() &&
                    candidate.resolve("klimiter-service").isDirectory()
            }
            ?: error("Could not find klimiter project root from '$start'")
    }
}

internal data class SourceFile(
    val path: String,
    val text: String,
) {
    val imports: List<String> = text
        .lineSequence()
        .map { it.trim() }
        .filter { it.startsWith("import ") }
        .map { it.removePrefix("import ").substringBefore(" as ").trim() }
        .toList()

    val packageName: String? = text
        .lineSequence()
        .firstOrNull { it.trim().startsWith("package ") }
        ?.trim()
        ?.removePrefix("package ")
        ?.trim()
}
