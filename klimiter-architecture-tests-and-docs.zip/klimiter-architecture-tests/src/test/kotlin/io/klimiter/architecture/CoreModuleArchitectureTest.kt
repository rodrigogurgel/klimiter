package io.klimiter.architecture

import kotlin.test.Test
import kotlin.test.assertFalse

class CoreModuleArchitectureTest {

    @Test
    fun `core must not depend on redis service or framework infrastructure`() {
        val forbiddenImports = listOf(
            "io.klimiter.redis",
            "io.klimiter.klimiterservice",
            "org.springframework",
            "io.lettuce",
            "com.google.protobuf",
            "io.grpc",
            "reactor.",
        )

        ArchitectureTestSupport.textFiles("klimiter-core").forEach { file ->
            val forbidden = file.imports.filter { import ->
                forbiddenImports.any(import::startsWith)
            }

            assertFalse(
                forbidden.isNotEmpty(),
                "${file.path} has forbidden imports for core module: $forbidden",
            )
        }
    }

    @Test
    fun `core spi must not depend on core internal implementation`() {
        ArchitectureTestSupport.textFiles("klimiter-core")
            .filter { it.packageName?.startsWith("io.klimiter.core.api.spi") == true }
            .forEach { file ->
                val forbidden = file.imports.filter { it.startsWith("io.klimiter.core.internal") }

                assertFalse(
                    forbidden.isNotEmpty(),
                    "${file.path} has SPI imports from internal implementation: $forbidden",
                )
            }
    }

    @Test
    fun `core internal implementation must stay inside internal package`() {
        val files = ArchitectureTestSupport.textFiles("klimiter-core")

        files
            .filter { it.path.contains("/internal/") }
            .forEach { file ->
                check(file.packageName?.contains(".internal") == true) {
                    "${file.path} is under internal directory but package is '${file.packageName}'"
                }
            }
    }
}
