package io.klimiter.architecture

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class ServiceModuleArchitectureTest {

    @Test
    fun `domain layer must not depend on adapters spring grpc core or redis`() {
        val forbiddenImports = listOf(
            "io.klimiter.klimiterservice.adapter",
            "io.klimiter.core",
            "io.klimiter.redis",
            "org.springframework",
            "io.grpc",
            "com.google.protobuf",
        )

        ArchitectureTestSupport.textFiles("klimiter-service")
            .filter { it.packageName?.startsWith("io.klimiter.klimiterservice.domain") == true }
            .forEach { file ->
                val forbidden = file.imports.filter { import -> forbiddenImports.any(import::startsWith) }

                assertFalse(
                    forbidden.isNotEmpty(),
                    "${file.path} has forbidden domain-layer imports: $forbidden",
                )
            }
    }

    @Test
    fun `application layer must depend on domain ports and not on transport infrastructure`() {
        val forbiddenImports = listOf(
            "io.klimiter.klimiterservice.adapter.input.grpc",
            "io.klimiter.klimiterservice.adapter.output.klimiter",
            "io.klimiter.core",
            "io.klimiter.redis",
            "io.grpc",
            "com.google.protobuf",
        )

        ArchitectureTestSupport.textFiles("klimiter-service")
            .filter { it.packageName?.startsWith("io.klimiter.klimiterservice.application") == true }
            .forEach { file ->
                val forbidden = file.imports.filter { import -> forbiddenImports.any(import::startsWith) }

                assertFalse(
                    forbidden.isNotEmpty(),
                    "${file.path} has forbidden application-layer imports: $forbidden",
                )
            }
    }

    @Test
    fun `service module should keep hexagonal package layout`() {
        val packages = ArchitectureTestSupport.textFiles("klimiter-service")
            .mapNotNull { it.packageName }
            .toSet()

        listOf(
            "io.klimiter.klimiterservice.domain.model",
            "io.klimiter.klimiterservice.domain.port.input",
            "io.klimiter.klimiterservice.domain.port.output",
            "io.klimiter.klimiterservice.application",
            "io.klimiter.klimiterservice.adapter.input.grpc",
            "io.klimiter.klimiterservice.adapter.output.klimiter",
            "io.klimiter.klimiterservice.config",
        ).forEach { expected ->
            assertTrue(
                packages.any { it == expected || it.startsWith("$expected.") },
                "Expected package '$expected' to exist",
            )
        }
    }
}
