package io.klimiter.architecture

import kotlin.test.Test
import kotlin.test.assertTrue

class ProjectStructureArchitectureTest {

    @Test
    fun `expected modules should exist`() {
        listOf(
            "klimiter-core",
            "klimiter-redis",
            "klimiter-service",
            "klimiter-architecture-tests",
        ).forEach(ArchitectureTestSupport::assertModuleExists)
    }

    @Test
    fun `main modules should contain Kotlin source files`() {
        listOf("klimiter-core", "klimiter-redis", "klimiter-service").forEach { module ->
            assertTrue(
                ArchitectureTestSupport.kotlinFiles(module).isNotEmpty(),
                "Expected module '$module' to contain Kotlin source files",
            )
        }
    }
}
