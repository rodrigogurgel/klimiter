package io.klimiter.architecture

import kotlin.test.Test
import kotlin.test.assertTrue

class KonsistSmokeArchitectureTest {

    @Test
    fun `konsist should be able to read all production scopes`() {
        val totalFiles = listOf("klimiter-core", "klimiter-redis", "klimiter-service")
            .sumOf { module -> ArchitectureTestSupport.scopeFromMain(module).files.size }

        assertTrue(totalFiles > 0, "Expected Konsist to read production Kotlin files")
    }
}
