package io.klimiter.architecture

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class RedisModuleArchitectureTest {

    @Test
    fun `redis module may depend on core but must not depend on service`() {
        ArchitectureTestSupport.textFiles("klimiter-redis").forEach { file ->
            val forbidden = file.imports.filter { it.startsWith("io.klimiter.klimiterservice") }

            assertFalse(
                forbidden.isNotEmpty(),
                "${file.path} has forbidden service imports: $forbidden",
            )
        }
    }

    @Test
    fun `redis module should contain public api and internal implementation packages`() {
        val packages = ArchitectureTestSupport.textFiles("klimiter-redis")
            .mapNotNull { it.packageName }
            .toSet()

        assertTrue(
            packages.any { it == "io.klimiter.redis.api" },
            "Expected Redis module to expose io.klimiter.redis.api package",
        )
        assertTrue(
            packages.any { it.startsWith("io.klimiter.redis.internal") },
            "Expected Redis module to contain io.klimiter.redis.internal implementation packages",
        )
    }

    @Test
    fun `redis internal implementation must stay inside internal package`() {
        ArchitectureTestSupport.textFiles("klimiter-redis")
            .filter { it.path.contains("/internal/") }
            .forEach { file ->
                check(file.packageName?.contains(".internal") == true) {
                    "${file.path} is under internal directory but package is '${file.packageName}'"
                }
            }
    }
}
