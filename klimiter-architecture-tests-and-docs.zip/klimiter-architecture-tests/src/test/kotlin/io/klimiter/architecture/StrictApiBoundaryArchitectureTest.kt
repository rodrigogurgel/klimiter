package io.klimiter.architecture

import org.junit.jupiter.api.Disabled
import kotlin.test.Test
import kotlin.test.assertFalse

/**
 * Stricter rules that are useful for library hardening, but currently expose design decisions
 * in the project. Enable these after deciding how strict the public API boundary should be.
 */
@Disabled("Enable after removing public API imports from internal implementation packages")
class StrictApiBoundaryArchitectureTest {

    @Test
    fun `core public api should not import core internal implementation`() {
        ArchitectureTestSupport.textFiles("klimiter-core")
            .filter { it.packageName?.startsWith("io.klimiter.core.api") == true }
            .forEach { file ->
                val forbidden = file.imports.filter { it.startsWith("io.klimiter.core.internal") }

                assertFalse(
                    forbidden.isNotEmpty(),
                    "${file.path} has public API imports from internal implementation: $forbidden",
                )
            }
    }

    @Test
    fun `redis public api should not import redis internal implementation`() {
        ArchitectureTestSupport.textFiles("klimiter-redis")
            .filter { it.packageName?.startsWith("io.klimiter.redis.api") == true }
            .forEach { file ->
                val forbidden = file.imports.filter { it.startsWith("io.klimiter.redis.internal") }

                assertFalse(
                    forbidden.isNotEmpty(),
                    "${file.path} has public API imports from internal implementation: $forbidden",
                )
            }
    }
}
